package com.capgemini.doctors.service;

public interface IDoctorAppointmentService {

}
