package com.capgemini.doctors.service;

import java.util.regex.Pattern;

public class DoctorServiceImp implements IDoctorAppointmentService {

	public boolean validateLetters(String paitentName) {
		Pattern pattern = Pattern.compile("^[A-Z][a-z]{1,}\\.?");
		java.util.regex.Matcher matcher = pattern.matcher(paitentName);
		return matcher.matches();
		
	}

	
	

	public boolean validateage(int age) {
		if (age > 15 && age < 100) {
			return true;
		}
		return false;
	}

	public int validateGender(String gender) {
		if (gender.equals("M") || (gender.equals("MALE"))) {
			return 1;
		} else if (gender.matches("F") || gender.matches("FEMALE")) {
			return 2;
		}

		return 0;
	
	}

	public boolean validateEmail(String email) {
		Pattern p = Pattern.compile("[a-zA-Z0-9-.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
		java.util.regex.Matcher matcher = p.matcher(email);

		return matcher.matches();
	}

	public boolean validatePhoneNumber(String phoneNumber) {
		Pattern pattern = Pattern.compile("(0/91)?[7-9][0-9]{9}");
		java.util.regex.Matcher matcher = pattern.matcher(phoneNumber);

		return matcher.matches();
	

}
}
