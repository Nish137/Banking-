package com.capgemini.doctors.dao;


import java.util.HashMap;
import java.util.Map;

import com.capgemini.doctors.bean.DoctorAppointment;

	public class DoctorAppointmentDao implements IDoctorAppointmentDao {

		Map<Long, DoctorAppointment> custList = new HashMap<Long, DoctorAppointment>();
		Map<Long, String> patient = new HashMap<Long, String>();

		
		      

	



		@Override
		public int addDoctorAppointmentDetails(
				DoctorAppointment doctorAppointment) {
			// TODO Auto-generated method stub
			return 0;
		}




		@Override
		public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) {
			// TODO Auto-generated method stub
			return null;
		}

		

	}



