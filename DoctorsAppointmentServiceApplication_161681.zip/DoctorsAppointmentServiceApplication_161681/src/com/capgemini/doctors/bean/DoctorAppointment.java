package com.capgemini.doctors.bean;

import java.time.LocalDate;

import com.capgemini.doctors.bean.DoctorAppointment.Gender;

public class DoctorAppointment {// bean class for Doctor Appointment with all
								// required properties;
/*	private long Id = (long) (Math.random() * 90000000) + 100000000;*/
    private int appointmentId=(int) ((long) (Math.random() * 90000000) + 100000000);;
	private String patientName;
	private String phoneNumber;
	private String email;
	private Gender gender;
	@Override
	public String toString() {
		return " Your Deatils:\nEnter Name of the patient :"+patientName+"\nEnter Phone Number   :"+phoneNumber+"\nEnter Email      :"+email+"\nEnter Age        :"+age+"\nEnter Gender     :"+gender;
	}
	private LocalDate appointmentDate;
	private int age;
	private String probleName;
	private String doctorName;
	private String appointmentStatus;
	public enum Gender {
	Male, female;
	}
	
	
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(LocalDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getProbleName() {
		return probleName;
	}
	public void setProbleName(String probleName) {
		this.probleName = probleName;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getAppointmentStatus() {
		return appointmentStatus;
	}
	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}
	public String Id() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setGender1(Gender a) {
		// TODO Auto-generated method stub
		
	}
	public void setGender(Gender b2) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
