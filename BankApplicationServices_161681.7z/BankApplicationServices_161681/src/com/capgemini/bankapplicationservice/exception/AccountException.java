package com.capgemini.bankapplicationservice.exception;

public class AccountException extends Exception  {

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public AccountException() {
			super();
		}

		public AccountException(Exception e) {
			e.getMessage();
		}

		public AccountException(String message) {
			// TODO Auto-generated constructor stub
		}

	}

