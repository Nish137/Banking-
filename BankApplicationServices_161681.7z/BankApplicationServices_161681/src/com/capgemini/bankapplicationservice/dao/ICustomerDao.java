package com.capgemini.bankapplicationservice.dao;
import java.util.List;

import com.capgemini.bankapplicationservice.bean.Customer;
import com.capgemini.bankapplicationservice.bean.Passbook;
import com.capgemini.bankapplicationservice.exception.AccountException;

public interface ICustomerDao 
	{
		public boolean createAccount(long accountNumber,Customer c) throws AccountException;
		public Customer showBalance(long accountNumber,int pin) throws AccountException;
		public boolean deposit(long accountNumber,int pin,double depositAmount) throws AccountException;
		public boolean withdraw(long accountNumber,int pin,double withdrawAmount) throws AccountException;
		public boolean fundTransfer(long depositorAccountNumber, int depositorPin, long recieverAccountNumber, double depositAmount) throws AccountException;
		public List<Passbook> printTansaction(long accountNumber,int pin) throws AccountException;
	}

