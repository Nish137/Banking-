package com.capgemini.bankapplicationservice.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bankapplicationservice.bean.Customer;
import com.capgemini.bankapplicationservice.bean.Passbook;
import com.capgemini.bankapplicationservice.exception.AccountException;
import com.capgemini.bankapplicationservice.service.CustomerServiceImp;

public class Client {

	public static void main(String[] args) throws AccountException {
		while (true) {
			@SuppressWarnings("resource")
			Scanner scanner = new Scanner(System.in);
			Customer bean = new Customer();
			CustomerServiceImp service = new CustomerServiceImp();

			long accountNumber;
			int pin;
			System.out
					.println("----------- Welcome to  Banking---------------");
			System.out.println("1. Create Account:");
			System.out.println("2. Show Balance:");
			System.out.println("3. Deposit:");
			System.out.println("4. Withdraw:");
			System.out.println("5. Fund Transfer:");
			System.out.println("6. Print Trasaction:");
			System.out.println("7. Exit:\n");
			System.out
					.println("-----------------------------------------------");
			System.out.print("\nEnter your choice: ");

			int choice = scanner.nextInt();

			switch (choice) {
			case 1:
				boolean flag = false;

				do {
					System.out.print("\nEnter your name: ");
					String name = scanner.next();
					if (service.validateName(name)) {
						System.out.println(name);
						flag = true;
						bean.setName(name);
					} else {

						System.err
								.println("\nInvalid... Name should start With capital letter Eg:Shiva!!!");
						flag = false;
					}

				} while (flag == false);

				do {
					System.out.print("\nEnter your Mobile Number : ");
					String phoneNumber = scanner.next();
					if (service.validatePhoneNumber(phoneNumber)) {
						System.out.println(phoneNumber);
						flag = true;
						bean.setPhoneNumber(phoneNumber);
					} else {

						System.err
								.println("Invalid... Number Should beign with 6-9 didgit!!!");
						flag = false;
					}
				} while (flag == false);

				do {
					System.out.print("\nEnter your Address : ");
					String address = scanner.next();
					if (service.validateAddress(address)) {
						System.out.println(address);
						flag = true;
						bean.setAddress(address);
					}

					else {
						System.err
								.println("Invalid Address [format: digits String String]...!!!");
						flag = false;
					}
				} while (flag == false);

				do {
					System.out
							.print("\nEnter your PAN number: ");
					String panNumber = scanner.next();
					if (service.validatePAN(panNumber)) {
						System.out.println(panNumber);
						flag = true;
						bean.setPanNumber(panNumber);
					} else {
						System.err
								.println("Invalid... Only 10 characters (alphanumeric) are allowed Eg:KJH123JKL2!!!");
						flag = false;
					}
				} while (flag == false);

				do {
					System.out.print("\nEnter your Aadhar number: ");
					String governmentID = scanner.next();
					if (service.validateAadhar(governmentID)) {
						System.out.println(governmentID);
						flag = true;
						bean.setGovernmentID(governmentID);
					} else {
						System.err.println("Please enter 12 digits!!!");
						flag = false;
					}

				} while (flag == false);
				
				
				do{
					
					System.out.print("\nEnter your Email ID:");
				      String  mailId  = scanner.next();
				       
					if(service.validateEmail(mailId)){
						System.out.println(mailId);
						flag=true;
						bean.setMailId(mailId);
						 
					}else{
						 System.err.println("please enter valid mailId:");
						 flag=false;
						 
					}
				}while(flag==false);
					 
					

				double a = (Math.random() * 90000 + 10000);
				accountNumber = (long) a;
				bean.setAccountNumber(accountNumber);
				System.out.print("\nYour Account number is : ");
				System.out.print(bean.getAccountNumber());

				double p = (Math.random() * 9000 + 1000);
				pin = (int) p;
				bean.setPin(pin);
				System.out.print("\nYour pin is : ");
				System.out.print(bean.getPin());
				System.out.println("\nbean " + bean);
				boolean isAdded = service.createAccount(accountNumber, bean);

				if (isAdded) {
					System.out.print("\n\nAccount created successfully...\n");
				} else {
					System.err.println("Account not created...");
				}

				break;

			case 2:

				System.out.print("\nEnter your Account number : ");
				accountNumber = scanner.nextLong();
				/* bean.setAccountNumber(accountNumber); */
				System.out.print("\nEnter PIN: ");
				pin = scanner.nextInt();

				Customer bean1 = service.showBalance(accountNumber, pin);
				if (bean1 != null)
					System.out.println(bean1.getBalance());
				else {
					try {
						throw new AccountException();

					} catch (AccountException e) {

						System.out
								.println("Please Enter Valid Accont Number and Valid PIn"
										+ e.getMessage());
					}
				}
				break;

			case 3:

				System.out.print("\nEnter your Account Number: ");
				accountNumber = scanner.nextLong();
				System.out.print("\nEnter PIN: ");
				pin = scanner.nextInt();
				System.out.print("\nEnter depositing amount: ");
				double depositAmount = scanner.nextDouble();

				boolean isDeposited = service.deposit(accountNumber, pin,
						depositAmount);
				if (isDeposited) {
					System.out
							.println("Rs." + depositAmount + " is Deposited.");
				} else {
					try {

						throw new AccountException();

					} catch (AccountException e) {

						System.err.println("Invalid... a/c no. or pin..."
								+ e.getMessage());
					}
				}
				break;

			case 4:

				System.out.print("\nEnter your Account Number: ");
				accountNumber = scanner.nextLong();
				System.out.print("\nEnter PIN: ");
				pin = scanner.nextInt();
				System.out.print("\nEnter withdraw amount: ");
				double withdrawAmount = scanner.nextDouble();

				boolean isWithdrawn = service.withdraw(accountNumber, pin,
						withdrawAmount);
				if (isWithdrawn) {
					System.out.println("Rs." + withdrawAmount
							+ " is Withdrawn.");
				} else {
					try {

						throw new AccountException();

					} catch (AccountException e) {

						System.err.println("Invalid... a/c no. or pin..."
								+ e.getMessage());
					}
				}

				break;

			case 5:

				System.out.print("\nEnter your Account Number: ");
				long accountNumber1 = scanner.nextLong();
				System.out.print("\nEnter your PIN: ");
				pin = scanner.nextInt();
				System.out.print("\nEnter Beneficiary's Account Number: ");
				long accountNumber2 = scanner.nextLong();
				System.out.print("\nEnter the amount to transfer: ");
				depositAmount = scanner.nextDouble();

				boolean isTransferred = service.fundTransfer(accountNumber1,
						pin, accountNumber2, depositAmount);
				if (isTransferred) {
					System.out.println("Rs." + depositAmount
							+ " is Transferred from " + accountNumber1 + " to "
							+ accountNumber2);
				} else {
					System.err.println("Transaction Unsuccessful....");
					throw new AccountException(
							"Please Enter valid account of yours and the Beneficiary account Number :");
				}
				break;

			case 6:

				System.out.print("\nEnter your Account Number: ");
				accountNumber = scanner.nextLong();
				System.out.print("\nEnter PIN: ");
				pin = scanner.nextInt();

				System.out
						.println("\n\n Date\t   Time\t       A/C No.\t\t Details \t\t\t\t\t\t\tBal");
				System.out
						.println("-----------------------------------------------------------------------------------------------------");
				service.printTansaction(accountNumber, pin);
				System.out
						.println("-----------------------------------------------------------------------------------------------------");
				try {
					List<Passbook> transList = service.printTansaction(
							accountNumber, pin);
					Iterator<Passbook> it = transList.iterator();
					while (it.hasNext()) {
						System.out.println(it.next());
					}
				} catch (AccountException e) {
					System.err.println(e.getMessage());
				}
				break;

			case 7:
				System.out
						.println("\n----Thank you for using Our Services----");
				System.exit(0);
				break;

			default:
				System.err.println("Please Enter right choice!!!");

			}
		}
	}

}
