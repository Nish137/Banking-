package com.capgemini.bankapplicationservice.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Customer_details")
	public class Customer 
	{
	     @Id
	    
		 private long accountNumber;
		 private String name;
		 private String phoneNumber;
		 private String panNumber;
		 private String address;
		 private String governmentID;
		 private String mailId;
		 private int pin;
		 private double balance;
		 @OneToMany(mappedBy="customer",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
		 private List<Passbook> passbook=new ArrayList<Passbook>();
			public List<Passbook> getPassbook() {
			return passbook;
		}


		public void setPassbook(List<Passbook> passbook) {
			this.passbook = passbook;
		}


			public Customer() {
				super();
			}

		 
		public Customer(long accountNumber, String name, String phoneNumber, String panNumber,
				String address, String governmentID, int pin, double balance) 
		{
			super();
			this.accountNumber = accountNumber;
			this.name = name;
			this.phoneNumber = phoneNumber;
			this.panNumber = panNumber;
			this.address = address;
			this.governmentID = governmentID;
			this.pin = pin;
			this.balance = balance;
		}
		


		public long getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(long accountNumber) {
			this.accountNumber = accountNumber;
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		public String getPanNumber() {
			return panNumber;
		}
		public void setPanNumber(String panNumber) {
			this.panNumber = panNumber;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getGovernmentID() {
			return governmentID;
		}
		public void setGovernmentID(String governmentID) {
			this.governmentID = governmentID;
		}
		
		
		public String getMailId() {
			return mailId;
		}


		public void setMailId(String mailId) {
			this.mailId = mailId;
		}


		public int getPin() {
			return pin;
		}
		public void setPin(int pin) {
			this.pin = pin;
		}
		
		
		public double getBalance() {
			return balance;
		}

		public void setBalance(double balance) {
			this.balance = balance;
		}

  public void addPassbook(Passbook passbook){
	  passbook.setCustomer(this);
	  this.getPassbook().add(passbook);
  }
  
  	@Override
	public String toString() {
		return "Customer Details: [accountNumber=" + accountNumber + ", name=" + name
				+ ", phoneNumber=" + phoneNumber + ", panNumber=" + panNumber
				+ ", address=" + address + ", governmentID=" + governmentID
				+ ", mailId=" + mailId + ", pin=" + pin + ", balance="
				+ balance + ", passbook=" + passbook + "]";
	}
		 
		 

	}


