package com.capgemini.bankapplicationservice.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.capgemini.bankapplicationservice.bean.Customer;
import com.capgemini.bankapplicationservice.bean.Passbook;
import com.capgemini.bankapplicationservice.dao.CustomerDaoImp;
import com.capgemini.bankapplicationservice.exception.AccountException;

public class CustomerDaoImpTest {
	
  Customer customer=new Customer(66666, "Matthew", "9885022003", "HGS123HGS1", "Hyderabad", "123456789123", 7777, 700.00);
  Customer customer1=new Customer();
  
 CustomerDaoImp dao=new CustomerDaoImp();
	@Test
	public void testCreateAccount() throws AccountException  {
		
		
			assertTrue(dao.createAccount(66666, customer));
	}

	@Test
	public void testShowBalance() throws AccountException {
		assertNotNull(dao.showBalance(66666,7777));
	}

	@Test
	public void testDeposit() {
		assertTrue(dao.deposit(66666,7777,700.00));
	}

	@Test
	public void testWithdraw() {
		assertTrue(dao.withdraw(66666,7777, 300.00));
	}

	@Test
	public void testFundTransfer() {
		assertTrue(dao.fundTransfer(66666,7777, 75555, 400.00));
	}

	@Test
	public void testPrintTansaction() {
		List<Passbook> passbook=new ArrayList<Passbook>();
		 passbook.add(new Passbook("Transactions"));
		 passbook.add(new Passbook("deatils"));
		 passbook.add(new Passbook("date "));
		 passbook.add(new Passbook("Time"));
		 passbook.add(new Passbook("transaction"));
		 assertEquals(4, passbook.size());
	}

}
