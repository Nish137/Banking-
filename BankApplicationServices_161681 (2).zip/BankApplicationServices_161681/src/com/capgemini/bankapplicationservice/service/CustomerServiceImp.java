package com.capgemini.bankapplicationservice.service;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bankapplicationservice.bean.Customer;
import com.capgemini.bankapplicationservice.bean.Passbook;
import com.capgemini.bankapplicationservice.dao.CustomerDaoImp;
import com.capgemini.bankapplicationservice.dao.ICustomerDao;
import com.capgemini.bankapplicationservice.exception.AccountException;

public class CustomerServiceImp implements ICustomerService {
		ICustomerDao dao=new CustomerDaoImp();
		Customer bean=new Customer();
		
		
		public boolean validateName(String name) throws AccountException
		{
			boolean flag=false;
			Pattern customerName=Pattern.compile("^[A-Z][A-Za-z\\s]*$");
			Matcher match = customerName.matcher(name);
			
			if(match.matches())
			{
				flag=true;
			}
			return flag;
		}
		
		public boolean validatePhoneNumber(String phoneNumber) throws AccountException
		{
			boolean flag=false;
			Pattern customerPhoneNo=Pattern.compile("\\d{10}");
			Matcher match = customerPhoneNo.matcher(phoneNumber);
			
			if(match.matches())
			{
				flag=true;
			}
			return flag;
		}
		
		
		public boolean validatePAN(String panNumber) throws AccountException
		{
			boolean flag=false;
			Pattern vPAN=Pattern.compile("[A-Z0-9]{10}");
			Matcher match = vPAN.matcher(panNumber);
			
			if(match.matches())
			{
				flag=true;
			}
			return flag;
		}
		
		
		public boolean validateAadhar(String governmentID) throws AccountException
		{
			boolean flag=false;
			Pattern vGovtID=Pattern.compile("\\d{12}");
			Matcher match = vGovtID.matcher(governmentID);
			
			if(match.matches())
			{
				flag=true;
			}
			return flag;
		}
		
		public boolean validateAddress(String address) throws AccountException
		{
			boolean flag=false;
			Pattern vAddress=Pattern.compile("[0-9A-Za-z/,\\s]+");
			Matcher match = vAddress.matcher(address);
			
			if(match.matches())
			{
				flag=true;
			}
			return flag;
		}
		
		@Override
		public boolean createAccount(long accountNumber,Customer c) throws AccountException
		{
			
			return dao.createAccount(accountNumber,c);
		}

		@Override
		public Customer showBalance(long accountNumber, int pin) throws AccountException 
		{
			
			return dao.showBalance(accountNumber, pin);
		}

		@Override
		public boolean deposit(long accountNumber, int pin, double depositAmount) throws AccountException
		{
			
			return dao.deposit(accountNumber, pin, depositAmount);
		}

		@Override
		public boolean withdraw(long accountNumber, int pin, double withdrawAmount) throws AccountException 
		{

			return dao.withdraw(accountNumber, pin, withdrawAmount);
		}

		@Override
		public boolean fundTransfer(long depositorAccountNumber, int depositorPin,
				long recieverAccountNumber, double depositAmount) throws AccountException
		{
		
			return dao.fundTransfer(depositorAccountNumber, depositorPin, recieverAccountNumber, depositAmount);
		}

		@Override
		public List<Passbook> printTansaction(long accountNumber, int pin) throws AccountException
		{
		
			return dao.printTansaction(accountNumber, pin);
		}


		
		
	}

