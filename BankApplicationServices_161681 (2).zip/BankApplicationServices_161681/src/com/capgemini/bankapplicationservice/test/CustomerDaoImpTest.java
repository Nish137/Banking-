package com.capgemini.bankapplicationservice.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.capgemini.bankapplicationservice.bean.Customer;

public class CustomerDaoImpTest {
	Customer bean=new Customer();
	@Test
	public void testCreateAccount() {
		assertNotNull(bean);
	}

	@Test
	public void testShowBalance() {
		assertNotNull(bean.getAccountNumber());
	}

	@Test
	public void testDeposit() {
		assertNotNull(bean.getAccountNumber());
	}

	@Test
	public void testWithdraw() {
		assertNotNull(bean.getAccountNumber());
	}

	@Test
	public void testFundTransfer() {
		assertNotNull(bean.getAccountNumber());
	}

	@Test
	public void testPrintTansaction() {
		assertNotNull(bean.getAccountNumber());
	}

}
