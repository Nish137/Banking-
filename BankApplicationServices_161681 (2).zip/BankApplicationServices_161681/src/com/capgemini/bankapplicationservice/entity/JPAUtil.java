package com.capgemini.bankapplicationservice.entity;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class JPAUtil {
public static EntityManager getEntityManager() {
		
		return Persistence.createEntityManagerFactory("BankApplicationServices_161681").createEntityManager();
}
}