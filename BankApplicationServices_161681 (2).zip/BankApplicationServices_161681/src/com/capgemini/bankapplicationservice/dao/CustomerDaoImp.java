package com.capgemini.bankapplicationservice.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capgemini.bankapplicationservice.bean.Customer;
import com.capgemini.bankapplicationservice.bean.Passbook;
import com.capgemini.bankapplicationservice.exception.AccountException;

public class CustomerDaoImp implements ICustomerDao {
	private EntityManagerFactory factory = Persistence.createEntityManagerFactory("BankApplicationServices_161681");
	
	static List<Passbook> transList = new ArrayList<Passbook>();
	Customer bean = new Customer();
	Passbook passbook = new Passbook();
	EntityManager entityManager = null;

	String string = null;

	@Override
	public boolean createAccount(long accountNumber, Customer bean) throws AccountException {
		try {
			entityManager = factory.createEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(bean);
			entityManager.getTransaction().commit();
			return entityManager.contains(bean);
		} catch (PersistenceException e) {
			throw new AccountException(e.getMessage());
		} finally {
			entityManager.close();
		}

	}

	@Override
	public Customer showBalance(long accountNumber, int pin) throws AccountException {
		try {

			entityManager = factory.createEntityManager();
			bean = entityManager.find(Customer.class, accountNumber);
			if ((bean.getAccountNumber() == accountNumber) && (bean.getPin() == pin)) {
				System.out.println(bean.getBalance());
				return bean;
			}
			return null;
		} catch (PersistenceException e) {
			e.printStackTrace();

			throw new AccountException(e.getMessage());

		} finally {
			entityManager.close();
		}
	}

	@Override
	public boolean deposit(long accountNumber, int pin, double depositAmount) {

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		entityManager = factory.createEntityManager();
		bean = entityManager.find(Customer.class, accountNumber);
		entityManager.getTransaction().begin();

		if ((bean.getAccountNumber() == accountNumber) && (bean.getPin() == pin)&&depositAmount>0 ) {

			

			double balance = bean.getBalance();
			System.out.println("Previous Balance = " + balance);
			balance = balance + depositAmount;
			bean.setBalance(balance);
			string = "\n" + dateFormat.format(date) + " : " + accountNumber + "\tdeposited Rs. " + depositAmount
					+ " \t\t\t\t\t\t" + balance;
			passbook.setTransactionDetails(string);
			bean.addPassbook(passbook);
			System.out.println("New Balance = " + bean.getBalance());
			entityManager.merge(bean);
			entityManager.getTransaction().commit();
			return true;
		}
		return false;
	}

	@Override
	public boolean withdraw(long accountNumber, int pin, double withdrawAmount) {

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		entityManager = factory.createEntityManager();
		bean = entityManager.find(Customer.class, accountNumber);
		entityManager.getTransaction().begin();

		if ((bean.getAccountNumber() == accountNumber) && (bean.getPin() == pin)
				&& (bean.getBalance() > withdrawAmount)) {
            double balance = bean.getBalance();
			System.out.println("Previous Balance = " + balance);

			balance = balance - withdrawAmount;
			System.out.println("New Balance = " + balance);
			bean.setBalance(balance);
		
			string = "\n" + dateFormat.format(date) + " : " + accountNumber + "\twithdrawn Rs. " + withdrawAmount
					+ " \t\t\t\t\t\t" + balance;
			passbook.setTransactionDetails(string);
			bean.addPassbook(passbook);
			entityManager.merge(bean);
			entityManager.getTransaction().commit();

			return true;
		}
		return false;
	}

	@Override
	public boolean fundTransfer(long depositorAccountNumber, int depositorPin, long recieverAccountNumber, double depositAmount) {
		Passbook pb1 = new Passbook();
		boolean flag = false;
		double debitAmount = 0.0;
		double creditAmount = 0.0;
		entityManager = factory.createEntityManager();
		EntityManager entityManager1 = factory.createEntityManager();
		bean = entityManager.find(Customer.class, depositorAccountNumber);
		entityManager.getTransaction().begin();

		if ((bean.getAccountNumber() == depositorAccountNumber) && (bean.getPin() == depositorPin) && (bean.getBalance() > depositAmount)) {

			

			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();

			debitAmount = bean.getBalance();
			debitAmount = debitAmount - depositAmount;
			bean.setBalance(debitAmount);

			string = "\n" + dateFormat.format(date) + " : " + depositorAccountNumber + "\tTransferred Rs. " + depositAmount + " to "
					+ recieverAccountNumber + "\t\t\t\t\t" + debitAmount;
			passbook.setTransactionDetails(string);
			bean.addPassbook(passbook);
			
			entityManager.merge(bean);
			entityManager.getTransaction().commit();

			System.out.println(debitAmount + " bal after (debit) fund transfer from" + depositorAccountNumber);

			Customer customer1 = entityManager1.find(Customer.class, recieverAccountNumber);
			entityManager1.getTransaction().begin();

			if (customer1.getAccountNumber() == recieverAccountNumber) {

				DateFormat dateFormat1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Date date1 = new Date();

				creditAmount = customer1.getBalance();
				creditAmount = creditAmount + depositAmount;
				customer1.setBalance(creditAmount);

			
				System.out.println(creditAmount + " bal after transaction(credited) to" + recieverAccountNumber);

				string = "\n" + dateFormat1.format(date1) + " : " + recieverAccountNumber + "\tCredited by Rs. " + depositAmount
						+ " on Fund Transfer from A/C " + depositorAccountNumber + " \t\t" + creditAmount;
				passbook.setTransactionDetails(string);
				bean.addPassbook(passbook);
				entityManager.merge(customer1);
			
				entityManager1.getTransaction().commit();
				flag = true;
			}


			else {
				System.out.println("Beneficiary's account oesn't exist...");
				flag = false;

			}

		}
		return flag;

	}

		@Override
	public List<Passbook> printTansaction(long accountNumber, int pin) throws AccountException {

		try {
			entityManager = factory.createEntityManager();
		
			bean = entityManager.find(Customer.class, accountNumber);
			List<Passbook> passbookList = bean.getPassbook();
			return passbookList;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new AccountException(e.getMessage());

		} finally {
			entityManager.close();
		}
	}
}
