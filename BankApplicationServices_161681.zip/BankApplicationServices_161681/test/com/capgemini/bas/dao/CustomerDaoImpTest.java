package com.capgemini.bas.dao;

import static org.junit.Assert.fail;

import org.junit.Test;

import com.capgemini.bas.bean.Customer;

public class CustomerDaoImpTest {
  Customer customer=new Customer();

	@Test
	public void testCreateAccount() {
		
	}

	@Test
	public void testShowBalance() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeposit() {
		fail("Not yet implemented");
	}

	@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintTansaction() {
		fail("Not yet implemented");
	}

}
