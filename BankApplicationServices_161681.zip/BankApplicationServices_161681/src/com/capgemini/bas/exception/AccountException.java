package com.capgemini.bas.exception;

public class AccountException extends Exception  {

		public AccountException() {
			super();
		}

		public AccountException(Exception e) {
			e.getMessage();
		}

		public AccountException(String message) {
			// TODO Auto-generated constructor stub
		}

	}

