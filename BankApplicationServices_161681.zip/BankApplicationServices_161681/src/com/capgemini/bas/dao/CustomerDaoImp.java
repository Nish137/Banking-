package com.capgemini.bas.dao;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capgemini.bas.bean.Customer;
import com.capgemini.bas.bean.Passbook;
import com.capgemini.bas.entity.JPAUtil;
import com.capgemini.bas.exception.AccountException;

	 public class CustomerDaoImp implements ICustomerDao {
		 private EntityManagerFactory factory=Persistence.createEntityManagerFactory("BankApplicationServices_161681");
		//static Map<Long, Customer> hashMap=new HashMap<Long, Customer>();
		//static Map<Long, StringBuffer> transactionMap=new HashMap<Long, StringBuffer>();
		
		//static List<String> tList=new ArrayList<String>();
		
		static List<Passbook> transList=new ArrayList<Passbook>();
		Customer bean=new Customer();
		Passbook pb=new Passbook();
		EntityManager entityManager=null;
		
		//StringBuffer sb=new StringBuffer();
		String str=null;
		
		@Override
		public boolean createAccount(long accountNumber, Customer bean) throws AccountException 
		{
			/*long a  = bean.getAccountNumber();
			hashMap.put(a, bean);*/
			//EntityManager entityManager=Persistence.createEntityManagerFactory("BankApplicationServices_161681").createEntityManager();
			//transactionMap.put(a, sb.append(bean));
			try{
			entityManager=factory.createEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(bean);
			entityManager.getTransaction().commit();
			return entityManager.contains(bean);
			}catch(PersistenceException e){
				throw new AccountException(e.getMessage());
			}finally{
				entityManager.close();
			}
			
		}

		@Override
		public Customer showBalance(long accountNumber, int pin) throws AccountException 
		{
			try {
				//DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				//Date date = new Date();
				entityManager=factory.createEntityManager();
				bean = entityManager.find(Customer.class, accountNumber);
				if((bean.getAccountNumber() == accountNumber) && (bean.getPin()==pin)){
					System.out.println(bean.getBalance());
					return bean;
				}
				return null;
			} catch (PersistenceException e) {
				e.printStackTrace();
				// TODO: Log to file
	            throw new AccountException(e.getMessage());
	            
	            
			} finally {
				entityManager.close();
			}   
		}
		

		@Override
		public boolean deposit(long accountNumber, int pin, double dAmount) 
		{	
			
		
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			entityManager=factory.createEntityManager();
			bean = entityManager.find(Customer.class, accountNumber);
			entityManager.getTransaction().begin();
			
			if((bean.getAccountNumber() == accountNumber) && (bean.getPin()==pin))
			{	
				
				//pb.setpAccountNumber(accountNumber);
			
				double bal=bean.getBalance();
				System.out.println("Previous Balance = "+ bal );
				bal=bal+dAmount;
				bean.setBalance(bal);
				//entityManager.merge(bean);
				str="\n"+dateFormat.format(date) +" : "+ accountNumber + "\tdeposited Rs. " + dAmount + " \t\t\t\t\t\t" + bal ;
				pb.setTransactionDetails(str);
				bean.addPassbook(pb);
				//transactionMap.put(accountNumber, sb.append(str));
				
				//tList.add(dateFormat.format(date) +" : "+ accountNumber + "\tdeposited Rs. " + dAmount + " \t\t\t\t\t\t" + bal);
				System.out.println("New Balance = " + bean.getBalance());
				entityManager.merge(bean);
				entityManager.getTransaction().commit();
				return true;
			}
			return false;
			}

		@Override
		public boolean withdraw(long accountNumber, int pin, double wAmount) 
		{
		
			
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			entityManager=factory.createEntityManager();
			bean= entityManager.find(Customer.class, accountNumber);
			entityManager.getTransaction().begin();
			
			if((bean.getAccountNumber() == accountNumber) && (bean.getPin()==pin) && (bean.getBalance()>wAmount))
			{
				
				
				/*pb.setpAccountNumber(accountNumber);
				*/
				double bal=bean.getBalance();
				System.out.println("Previous Balance = "+ bal );

					bal=bal-wAmount;
					System.out.println("New Balance = "+bal);
					bean.setBalance(bal);
					//
					str="\n"+dateFormat.format(date) +" : "+accountNumber + "\twithdrawn Rs. " + wAmount + " \t\t\t\t\t\t" + bal ;
					pb.setTransactionDetails(str);
					bean.addPassbook(pb);
					entityManager.merge(bean);
					//transactionMap.put(accountNumber, sb.append(str));	
				//tList.add(dateFormat.format(date) +" : "+accountNumber + "\twithdrawn Rs. " + wAmount + " \t\t\t\t\t\t" + bal);
				//transList.add(pb);
				entityManager.getTransaction().commit();
				
			
			return true;
			}
				return false;	
		}

		@Override
		public boolean fundTransfer(long dAccountNumber, int dpin,
				long cAccountNumber, double dAmount) 
		{
			Passbook pb1=new Passbook();
			boolean flag=false;
			double deb=0.0;
			double cred=0.0;
			entityManager=factory.createEntityManager();
			EntityManager entityManager1=factory.createEntityManager();
			bean= entityManager.find(Customer.class, dAccountNumber);
			entityManager.getTransaction().begin();
			
			
				if((bean.getAccountNumber() == dAccountNumber) && (bean.getPin()==dpin)&& (bean.getBalance()>dAmount))
				{
					
					//pb.setpAccountNumber(dAccountNumber);
		
					DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					Date date = new Date();

					deb=bean.getBalance();
					deb=deb-dAmount;
					bean.setBalance(deb);
					
					str="\n"+dateFormat.format(date) +" : "+dAccountNumber + "\tTransferred Rs. " + dAmount +" to " + cAccountNumber + "\t\t\t\t\t" + deb ;
					pb.setTransactionDetails(str);
					bean.addPassbook(pb);
					/*transList.add(pb);*/
					entityManager.merge(bean);
					entityManager.getTransaction().commit();
					
					System.out.println(deb+" bal after (debit) fund transfer from" + dAccountNumber);
					
					
					//transactionMap.put(dAccountNumber, sb.append(str));	
					//tList.add(dateFormat.format(date) +" : "+dAccountNumber + "\tTransferred Rs. " + dAmount +" to " + cAccountNumber + "\t\t\t\t\t" + deb);
					
					
					Customer c1 = entityManager1.find(Customer.class, cAccountNumber);
					entityManager1.getTransaction().begin();
					
						if(c1.getAccountNumber() == cAccountNumber)
						{
							
							DateFormat dateFormat1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
							Date date1 = new Date();
		
							cred=c1.getBalance();
							cred=cred+dAmount;
							c1.setBalance(cred);
							
							/*entityManager.getTransaction().commit();*/
							System.out.println(cred+" bal after transaction(credited) to" + cAccountNumber);
												
							str="\n" + dateFormat1.format(date1) +" : "+cAccountNumber + "\tCredited by Rs. " + dAmount +" on Fund Transfer from A/C " + dAccountNumber + " \t\t" + cred ;
							pb.setTransactionDetails(str);
							bean.addPassbook(pb);
							entityManager.merge(c1);
							/*transList.add(pb);*/
							entityManager1.getTransaction().commit();
							flag=true;
						}
						
							
							//transactionMap.put(cAccountNumber, sb.append(str));
							//tList.add(dateFormat1.format(date1) +" : "+cAccountNumber + "\tCredited by Rs. " + dAmount+" on Fund Transfer from A/C " + dAccountNumber + " \t\t" + cred);
							
						
						else
						{
							System.out.println("Beneficiary's account oesn't exist...");
							flag=false;
							
						}
				
						
					}
				return flag;
				
		}
		
			
		
		

	/*	@Override
		public boolean printTansaction(long accountNumber, int pin) 
		{						
						Iterator<String> itr = tList.iterator();
						while (itr.hasNext()) 
						{
							Object element = itr.next();
							System.out.println(element + "\n");
							
							
						}
		return true;
		
		}
	}
	*/
		@Override
		public List<Passbook> printTansaction(long accountNumber, int pin) throws AccountException{
			
			try{
				 entityManager=factory.createEntityManager();
				 /* entityManager =JPAUtil.getEntityManager();*/
				 bean=entityManager.find(Customer.class, accountNumber);
				/*  Query query=entityManager.createQuery("from Passbook Where pAccountNumber=?");
				  query.setParameter(1, accountNumber);*/
				  List<Passbook> passbookList=bean.getPassbook();
				  return passbookList;
			 }
			 catch (PersistenceException e)
			 {
				  e.printStackTrace();
				   throw new AccountException(e.getMessage());
				   
			 }
		      finally{
		    	   entityManager.close();
		      }
	}
	 }
	 
	



