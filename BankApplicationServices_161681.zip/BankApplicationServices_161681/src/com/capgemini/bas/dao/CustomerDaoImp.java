package com.capgemini.bas.dao;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capgemini.bas.bean.Customer;
import com.capgemini.bas.bean.Passbook;
import com.capgemini.bas.entity.JPAUtil;
import com.capgemini.bas.exception.AccountException;

	 public class CustomerDaoImp implements ICustomerDao {
		 private EntityManager entityManager=Persistence.createEntityManagerFactory("BankApplicationServices_161681").createEntityManager();
		static Map<Long, Customer> hashMap=new HashMap<Long, Customer>();
		//static Map<Long, StringBuffer> transactionMap=new HashMap<Long, StringBuffer>();
		
		static List<String> tList=new ArrayList<String>();
		
		static List<Passbook> transList=new ArrayList<Passbook>();
		Customer bean=new Customer();
		Passbook pb=new Passbook();
		
		//StringBuffer sb=new StringBuffer();
		String str=null;
		
		@Override
		public boolean createAccount(long accountNumber, Customer bean) 
		{
			/*long a  = bean.getAccountNumber();
			hashMap.put(a, bean);*/
			//EntityManager entityManager=Persistence.createEntityManagerFactory("BankApplicationServices_161681").createEntityManager();
			//transactionMap.put(a, sb.append(bean));
			entityManager.getTransaction().begin();
			entityManager.persist(bean);
			entityManager.getTransaction().commit();
			return entityManager.contains(bean);
			
		}

		@Override
		public Customer showBalance(long accountNumber, int pin) 
		{
			try {
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Date date = new Date();
				entityManager = JPAUtil.getEntityManager();
				entityManager.getTransaction().begin();
				Customer c = entityManager.find(Customer.class, accountNumber);
				if((c.getAccountNumber() == accountNumber) && (c.getPin()==pin)){
					System.out.println(c.getBalance());
					entityManager.getTransaction().commit();
					return c;
				}
				return null;
			} catch (PersistenceException e) {
				e.printStackTrace();
				// TODO: Log to file
				try {
					throw new AccountException(e.getMessage());
				} catch (AccountException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} finally {
				entityManager.close();
			}
			return bean;
           
		}
		

		@Override
		public boolean deposit(long accountNumber, int pin, double dAmount) 
		{	
			
		
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			Customer c = entityManager.find(Customer.class, accountNumber);
			entityManager.getTransaction().begin();
			
			if((c.getAccountNumber() == accountNumber) && (c.getPin()==pin))
			{	
				
				pb.setpAccountNumber(accountNumber);
			
				double bal=c.getBalance();
				System.out.println("Previous Balance = "+ bal );
				bal=bal+dAmount;
				c.setBalance(bal);
				entityManager.merge(c);
				str="\n"+dateFormat.format(date) +" : "+ accountNumber + "\tdeposited Rs. " + dAmount + " \t\t\t\t\t\t" + bal ;
				pb.setTransactionDetails(str);
				//transactionMap.put(accountNumber, sb.append(str));
				
				//tList.add(dateFormat.format(date) +" : "+ accountNumber + "\tdeposited Rs. " + dAmount + " \t\t\t\t\t\t" + bal);
				System.out.println("New Balance = " + c.getBalance());
				entityManager.merge(pb);
				entityManager.getTransaction().commit();
				return true;
			}
			return false;
			}

		@Override
		public boolean withdraw(long accountNumber, int pin, double wAmount) 
		{
		
			
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			
			Customer c = entityManager.find(Customer.class, accountNumber);
			entityManager.getTransaction().begin();
			
			if((c.getAccountNumber() == accountNumber) && (c.getPin()==pin) && (c.getBalance()>wAmount))
			{
				
				
				pb.setpAccountNumber(accountNumber);
				
				double bal=c.getBalance();
				System.out.println("Previous Balance = "+ bal );

					bal=bal-wAmount;
					System.out.println("New Balance = "+bal);
					c.setBalance(bal);
					entityManager.merge(c);
					str="\n"+dateFormat.format(date) +" : "+accountNumber + "\twithdrawn Rs. " + wAmount + " \t\t\t\t\t\t" + bal ;
					pb.setTransactionDetails(str);
					//transactionMap.put(accountNumber, sb.append(str));	
				//tList.add(dateFormat.format(date) +" : "+accountNumber + "\twithdrawn Rs. " + wAmount + " \t\t\t\t\t\t" + bal);
				transList.add(pb);
				entityManager.getTransaction().commit();
				
			
			return true;
			}
				return false;	
		}

		@Override
		public boolean fundTransfer(long dAccountNumber, int dpin,
				long cAccountNumber, double dAmount) 
		{
			boolean flag=false;
			double deb=0.0;
			double cred=0.0;
			
			Customer c = entityManager.find(Customer.class, dAccountNumber);
			entityManager.getTransaction().begin();
			
			
				if((c.getAccountNumber() == dAccountNumber) && (c.getPin()==dpin)&& (c.getBalance()>dAmount))
				{
					flag=true;
					pb.setpAccountNumber(dAccountNumber);
		
					DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					Date date = new Date();

					deb=c.getBalance();
					deb=deb-dAmount;
					c.setBalance(deb);
					entityManager.merge(c);
					str="\n"+dateFormat.format(date) +" : "+dAccountNumber + "\tTransferred Rs. " + dAmount +" to " + cAccountNumber + "\t\t\t\t\t" + deb ;
					pb.setTransactionDetails(str);
					transList.add(pb);
					entityManager.getTransaction().commit();
					
					System.out.println(deb+" bal after (debit) fund transfer from" + dAccountNumber);
					
					
					//transactionMap.put(dAccountNumber, sb.append(str));	
					//tList.add(dateFormat.format(date) +" : "+dAccountNumber + "\tTransferred Rs. " + dAmount +" to " + cAccountNumber + "\t\t\t\t\t" + deb);
					
					
					Customer c1 = entityManager.find(Customer.class, cAccountNumber);
					entityManager.getTransaction().begin();
					
						if(c1.getAccountNumber() == cAccountNumber)
						{
							final Customer c11= c1;
							flag=true;
							pb.setpAccountNumber(cAccountNumber);
							
							DateFormat dateFormat1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
							Date date1 = new Date();
		
							cred=c11.getBalance();
							cred=cred+dAmount;
							c11.setBalance(cred);
							entityManager.merge(c1);
							/*entityManager.getTransaction().commit();*/
							System.out.println(cred+" bal after transaction(credited) to" + cAccountNumber);
												
							str="\n" + dateFormat1.format(date1) +" : "+cAccountNumber + "\tCredited by Rs. " + dAmount +" on Fund Transfer from A/C " + dAccountNumber + " \t\t" + cred ;
							pb.setTransactionDetails(str);
							transList.add(pb);
							entityManager.getTransaction().commit();
						}
						
							
							//transactionMap.put(cAccountNumber, sb.append(str));
							//tList.add(dateFormat1.format(date1) +" : "+cAccountNumber + "\tCredited by Rs. " + dAmount+" on Fund Transfer from A/C " + dAccountNumber + " \t\t" + cred);
							
						
						else
						{
							System.out.println("Beneficiary's account oesn't exist...");
							flag=false;
							
						}
				
						
					}
				return flag;
				
		}
		
			
		
		

	/*	@Override
		public boolean printTansaction(long accountNumber, int pin) 
		{						
						Iterator<String> itr = tList.iterator();
						while (itr.hasNext()) 
						{
							Object element = itr.next();
							System.out.println(element + "\n");
							
							
						}
		return true;
		
		}
	}
	*/
		@Override
		public List<Passbook> printTansaction(long accountNumber, int pin) throws AccountException{
			 try{
				  entityManager =JPAUtil.getEntityManager();
				  Query query=entityManager.createQuery("from Passbook Where pAccountNumber=?");
				  query.setParameter(1, accountNumber);
				  List<Passbook> passbookList=query.getResultList();
				  return passbookList;
			 }
			 catch (PersistenceException e)
			 {
				  e.printStackTrace();
				   throw new AccountException(e.getMessage());
				   
			 }
		      finally{
		    	   entityManager.close();
		      }
	}
	 }
	 
	



