package com.capgemini.bas.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Passbook {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int transactionid;
	private long pAccountNumber;
	private String transactionDetails;

	public Passbook() {
		super();
	}
     
	public int getTransactionid() {
		return transactionid;
	}

	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}

	public long getpAccountNumber() {
		return pAccountNumber;
	}

	public void setpAccountNumber(long pAccountNumber) {
		this.pAccountNumber = pAccountNumber;
	}

	public String getTransactionDetails() {
		return transactionDetails;
	}

	public void setTransactionDetails(String transactionDetails) {
		this.transactionDetails = transactionDetails;
	}

	@Override
	public String toString() {
		return "Passbook [transactionid=" + transactionid + ", pAccountNumber="
				+ pAccountNumber + ", transactionDetails=" + transactionDetails
				+ "]";
	}

	public Passbook(long pAccountNumber, String transactionDetails) {
		super();
		this.pAccountNumber = pAccountNumber;
		this.transactionDetails = transactionDetails;
	}

}
