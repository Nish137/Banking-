package com.capg.ba.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capg.ba.bean.Customer;

class CustomerServiceImpTest {
	Customer c=new Customer();

	@Test
	void testShowBalanceLongInt() {
	
	}

	@Test
	void testDisplayCustomer() {
		
	}

	@Test
	void testDeposit() {
		
	}

	@Test
	void testWithDraw() {
		
	}

	@Test
	void testFundTransfer() {
		
	}

	@Test
	void testPrintTransactions1() {
	}

	@Test
	void testCreateAccount() {
	
	}

	@Test
	void testShowBalanceDoubleInt() {
	
	}

	@Test
	void testPrintTransactionsDoubleInt() {
		
	}

	@Test
	void testPrintTransaction() {
	
	}

}
