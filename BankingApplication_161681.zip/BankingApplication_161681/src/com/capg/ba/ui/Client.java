package com.capg.ba.ui;
import java.util.Scanner;
import com.capg.ba.bean.Customer;
import com.capg.ba.bean.Customer.Gender;
import com.capg.ba.exception.CustomerNotFound;
import com.capg.ba.service.CustomerServiceImp;

public class Client {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("*****************************");
		System.out.println("Welcome To Banking:");
		System.out.println("*****************************");
		while (true) {
			System.out.println("Enter your Choice:");
			System.out.println("1.Create Account:");
			System.out.println("2.Show Balance:");
			System.out.println("3.Deposit:");
			System.out.println("4.Withdraw:");
			System.out.println("5.Fund Transfer:");
			System.out.println("6.PrintTranaction:");
			System.out.println("7.Exit:");
			int choice = sc.nextInt();
			CustomerServiceImp service = new CustomerServiceImp();
			switch (choice) {
			case 1:
				Customer bean = new Customer();

				boolean b;

				do {

					System.out.println("Enter your FirstName:");
					String fName = sc.next();
					bean.setfName(fName);
					b = service.validateLetters(fName);
					if (b) {
						break;
					} else
						System.err.println("Please Enter your name Staring with capital letter:");
				} while (!b);

				do {
					System.out.println("Enter your LastName:");
					String lName = sc.next();
					bean.setlName(lName);
					b = service.validateLetters(lName);
					if (b) {
						break;
					} else
						System.out.println("Please Enter your name Staring with capital letter:");
				} while (!b);

				do {
					System.out.println("Enter your MobileNumber:");
					String mobileNo = sc.next();
					bean.setMobileNo(mobileNo);
					b = service.validatemobileNo(mobileNo);
					if (b) {
						break;
					} else
						System.err.println("Phone Number must be in the form XXXXXXXXXX");
				} while (!b);

				do {
					System.out.println("Enter your Age:");
					int age = sc.nextInt();
					bean.setAge(age);
					b = service.validateage(age);
					if (b) {

					} else
						System.err.println("Age should be greater than 15:");
				} while (!b);

				int b1;
				do {
					System.out.println("ENTER GENDER");
					String gender = sc.next().toUpperCase();
					b1 = service.validateGender(gender);
					if (b1 == 1) {

						Gender a = Gender.M;
						bean.setGender(a);
					} else if (b1 == 2) {
						Gender b2 = Gender.f;
						bean.setGender(b2);
					} else {
						System.err.println("Please enter valid gender. Please select  M for Male or F for Female");
					}
				} while (b1 == 0);
				do {
					System.out.println("Enter your AadharNumber:");
					String aadharNo = sc.next();
					bean.setAadharNo(aadharNo);
					b = service.validateAadharNumber(aadharNo);
					if (b) {

					} else
						System.err.println("Aadhar number Should be 12 digits:");
				} while (!b);

				do {
					System.out.println("Enter your E-mail:");
					String e_mail = sc.next();
					bean.setE_mail(e_mail);
					b = service.validateE_mail(e_mail);
					if (b) {

					} else
						System.out.println("Enter valid Email:");
				} while (!b);

				do {
					System.out.println("Enter Your Address:");
					StringBuffer address = new StringBuffer();
					;
					StringBuffer address1 = new StringBuffer();
					;
					StringBuffer address2 = new StringBuffer();
					;
					StringBuffer address3 = new StringBuffer();
					;
					StringBuffer address4 = new StringBuffer();
					;
					String address5;
					System.out.println("H.No./Flat No.");
					address1.append(sc.next());
					System.out.println("Street Name/Colony Name/Area");
					address2.append(sc.next());
					System.out.println("City");
					address3.append(sc.next());
					System.out.println("State");
					address4.append(sc.next());
					System.out.println("Pincode");
					address5 = sc.next();
					address = address1.append(", " + address2).append(", " + address3).append("," + address4)
							.append("-" + address5);
					bean.setAddress(address);
					b = service.validataeAddress(address);

					if (b) {
						break;
					} else {
						System.out.println("enter correct address:");
					}
				} while (!b);

				System.out.println("Enter the minimum balance for your account:");
				double amt = sc.nextDouble();
				bean.setAmount(amt);
				System.out.println();
				System.out.println("Congratulations!!: Your account has been created!!:");

				System.err.println("*****************************************\n");
				System.out.println("Your Account Number and Pin are:");
				System.out.println("Account Number :" + bean.getAccNo());
				System.out.println("Pin            :" + bean.getPin());

				System.out.println(bean);
				break;
			case 2:
				boolean isvalidacc = false, isvalidpin = false;
				do {
					System.out.println("ENTER ACCOUNT ID TO GET THE BALANCE");
					long cid = sc.nextLong();
					isvalidacc = service.validateAccountNumber(cid);
					if (isvalidacc) {
						System.out.println("ENTER YOUR PIN");
						int pin = sc.nextInt();
						isvalidpin = service.validatePin(pin);
						if (isvalidpin) {
							Customer c = service.displayCustomer(cid);
							if (c.getAccNo() == cid && c.getPin() == pin) {
								service.showBalance(cid, pin);
							} else {
								System.err.println("Please enter correct pin");
							}

						} else {
							System.err.println("Please enter correct pin");
						}
					}
					// System.out.println(c.getBalance());

					/*
					 * if (c) { Customer c1=service.showBalance(cid, pin);
					 * System.out.println(c1.getOpeningBalance()); }else{
					 * System.out.println("PLEASE ENTER CORRECT PIN"); } }
					 */
					else {
						try {
							throw new CustomerNotFound("Please enter a valid Account Number");
						} catch (CustomerNotFound e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
					}
				} while (!isvalidacc || !isvalidpin);
				break;

			case 3:
				boolean isvalid = false, isvalid1 = false;
				do {
					System.out.println("Enter Account No.");
					long acc1 = sc.nextLong();
					isvalid = service.validateAccountNumber(acc1);
					if (isvalid) {
						System.out.println("Enter pin:");
						int pin1 = sc.nextInt();
						isvalid1 = service.validatePin(pin1);
						if (isvalid1) {
							Customer c = service.displayCustomer(acc1);
							if (c.getAccNo() == acc1 && c.getPin() == pin1) {
								System.out.println("Enter deposit amount");
								long deposit = sc.nextLong();
								double amount = c.getAmount();
								long a = service.deposit(c, deposit);
								service.printTransaction(c);
								if (a > amount) {
									System.out.println("Successfully Deposited....");
									System.out.println("Updated Balance:" + a);
								} else {
									System.err.println("Deposition Failed");
								}
							} else {
								System.err.println("Please enter correct pin");
							}
						} else {
							System.err.println("Please enter valid pin");
						}
					} else {
						try {
							throw new CustomerNotFound("Please enter a valid Account Number");
						} catch (CustomerNotFound e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
					}
				} while (!isvalid || !isvalid1);
				break;
			case 4:
				boolean isvalid2 = false, isvalid3 = false;
				do {
					System.out.println("Enter Account No.");
					long acc2 = sc.nextLong();
					isvalid2 = service.validateAccountNumber(acc2);
					if (isvalid2) {
						System.out.println("Enter pin:");
						int pin2 = sc.nextInt();
						isvalid3 = service.validatePin(pin2);
						if (isvalid3) {
							Customer c = service.displayCustomer(acc2);
							if (c.getAccNo() == acc2 && c.getPin() == pin2) {
								System.out.println("Enter withdraw amount");
								long withdraw = sc.nextLong();
								double amount = c.getAmount();
								double a = service.withDraw(c, amount);
								service.printTransaction(c);
								if (a < amount) {
									System.out.println("Successfully WithDrawn");
									System.out.println("Updated Balance:" + a);
								} else {
									System.err.println("Sorry Insufficient Balance");
								}
							} else {
								System.err.println("Please enter correct pin");
							}
						} else {
							System.err.println("Please enter valid pin");
						}
					} else {
						try {
							throw new CustomerNotFound("Please enter a valid Account Number");
						} catch (CustomerNotFound e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
					}
				} while (!isvalid2 || !isvalid3);
				break;
			case 5:
				boolean isvalid4 = false, isvalid5 = false, isvalid6 = false, isvalid9 = false;
				do {
					System.out.println("Enter Account No.");
					long acc3 = sc.nextLong();
					isvalid4 = service.validateAccountNumber(acc3);
					if (isvalid4) {
						Customer cust3 = service.displayCustomer(acc3);
						System.out.println("Enter pin:");
						int pin3 = sc.nextInt();
						isvalid5 = service.validatePin(pin3);
						if (isvalid5) {
							if (cust3.getAccNo() == acc3 && cust3.getPin() == pin3) {
								System.out.println("Enter the Account Number to transfer:");
								long acc4 = sc.nextLong();
								isvalid6 = service.validateAccountNumber(acc4);
								if (isvalid6) {
									System.out.println("Enter Name of the Receiver:");
									String sName = sc.next();
									System.out.println("Enter IFSC Code");
									int ifsc = sc.nextInt();
									System.out.println("Enter amount of transfer:");
									long deposit = sc.nextLong();
									Customer cust4 = service.displayCustomer(acc4);
									isvalid9 = service.fundTransfer(cust3, cust4, deposit, acc3, acc4, pin3);
									if (isvalid9) {
										service.printTransaction(cust3);
										service.printTransaction(cust4);
										System.out.println("Transaction Successful");
										System.out.println(
												"Account No:" + acc3 + "Amount after deduction:" + cust3.getAmount());
										System.out.println(
												"Account No:" + acc4 + "Amount after Credit:" + cust4.getAmount());
									} else {
										System.err.println("Insufficient Balance:");
									}
								} else {
									System.err.println("Please enter valid Account No.");
								}
							} else {
								System.err.println("Please enter valid pin");
							}
						} else {
							System.err.println("Please enter valid pin");
						}
					} else {
						try {
							throw new CustomerNotFound("Please enter a valid Account Number");
						} catch (CustomerNotFound e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
					}
				} while (!isvalid4 || !isvalid5 || !isvalid6);
				break;
			case 6:
				boolean isvalid7 = false, isvalid8 = false;
				do {
					System.out.println("ENTER ACCOUNT ID TO GET THE BALANCE");
					long cid = sc.nextLong();
					isvalid7 = service.validateAccountNumber(cid);
					if (isvalid7) {
						System.out.println("ENTER YOUR PIN");
						int pin = sc.nextInt();
						isvalid8 = service.validatePin(pin);
						if (isvalid8) {
							Customer c = service.displayCustomer(cid);
							if (c.getAccNo() == cid && c.getPin() == pin) {
								service.printTransactions(cid, pin);
							} else {
								System.err.println("Please enter correct pin");
							}

						} else {
							System.err.println("Please enter valid pin");
						}
					} else {
						try {
							throw new CustomerNotFound("Please enter a valid Account Number");
						} catch (CustomerNotFound e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
					}
				} while (!isvalid7 || !isvalid8);
				break;
			case 7:
				System.out.println("********************************************");
				System.out.println("--------------------------------------------");
				System.out.println("Thank You for using Our Banking Service..");
				System.out.println("--------------------------------------------");
				System.out.println("********************************************");
				sc.close();
				System.exit(0);
				break;

			default:
				System.out.println("Invalid choice");
				break;
			}
		}
	}
}
