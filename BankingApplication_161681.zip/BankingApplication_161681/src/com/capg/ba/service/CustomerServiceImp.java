package com.capg.ba.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.ba.bean.Customer;
import com.capg.ba.dao.CustomerDaoImp;

public class CustomerServiceImp implements ICustomerService {
	Customer bean = new Customer();
	CustomerDaoImp dao = new CustomerDaoImp();

	public boolean validateLetters(String fName) {

		/* String regx = "[A-Za-z]+\\.?"; */
		Pattern pattern = Pattern.compile("^[A-Z][a-z]{1,}\\.?");
		Matcher matcher = pattern.matcher(fName);
		return matcher.matches();
	}

	public boolean validateage(int age) {
		if (age > 15 && age < 100) {
			return true;
		}
		return false;
	}

	public boolean validatemobileNo(String mobileNo) {
		/* String regex = "(0/91)?[7-9][0-9]{9}"; */
		Pattern pattern = Pattern.compile("(0/91)?[7-9][0-9]{9}");
		Matcher matcher = pattern.matcher(mobileNo);

		return matcher.matches();

	}

	public boolean validateAadharNumber(String aadharNo) {
		Pattern pattern = Pattern.compile("\\d{12}");
		Matcher matcher = pattern.matcher(aadharNo);
		return matcher.matches();

	}

	public boolean validateE_mail(String e_mail) {
		Pattern p = Pattern.compile("[a-zA-Z0-9-.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
		Matcher matcher = p.matcher(e_mail);

		return matcher.matches();
	}

	public boolean validataeAddress(StringBuffer address) {
		Pattern p = Pattern.compile("^[#.0-9 a-zA-Z,\\u0020-]+$");
		Matcher matcher = p.matcher(address);

		return matcher.matches();
	}

	public int validateGender(String gender) {

		// TODO Auto-generated method stub
		if (gender.equals("M") || (gender.equals("MALE"))) {
			return 1;
		} else if (gender.matches("F") || gender.matches("FEMALE")) {
			return 2;
		}

		return 0;
	}

	public boolean validateAccountNumber(long cid) {
		// TODO Auto-generated method stub
		return dao.validateAccountNumber(cid);
	}

	public boolean validatePin(int pin) {
		// TODO Auto-generated method stub
		return dao.validatePin(pin);
	}

	public double showBalance(long cid, int pin) {
		return dao.showBalance(cid, pin);
		// TODO Auto-generated method stub

	}

	public Customer displayCustomer(long accountNo) {
		// TODO Auto-generated method stub
		return dao.displayCustomer(accountNo);
	}

	public long deposit(Customer c, long deposit) {
		// TODO Auto-generated method stub
		return 0;
	}

	public void printTransaction1(Customer c) {
		// TODO Auto-generated method stub

	}

	public double withDraw(Customer c, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean fundTransfer(Customer cust3, Customer cust4, long deposit, long acc3, long acc4, int pin3) {
		// TODO Auto-generated method stub
		return false;
	}

	

	@Override
	public boolean createAccount(Customer c) {
		// TODO Auto-generated method stub
		return dao.equals(c);
	}

	@Override
	public Customer printTransaction(Customer c) {
		// TODO Auto-generated method stub
		return dao.printTransaction(c);
	}

	@Override
	public Customer printTransactions(long cid, int pin) {
		// TODO Auto-generated method stub
		return dao.printTransactions(cid, pin);
	}

	@Override
	public double deposit(Customer c, double amount) {
		// TODO Auto-generated method stub
		return dao.deposit(c, amount);
	}

	@Override
	public boolean fundTransfer(Customer c, Customer b, double amount, long acc1, long acc2, int pin1) {
		// TODO Auto-generated method stub
		return dao.fundTransfer(c, b, amount, acc1, acc2, pin1);
	}

}
