package com.capg.ba.bean;

public class Customer {
	private long accNo = (long) (Math.random() * 90000000) + 100000000;
	private int pin = (int) (Math.random() * 90000) + 10000;
	private String fName;
	private String lName;
	private String e_mail;
	private int age;
	private Gender gender;
	private String aadharNo;
	private String mobileNo;
    private double amount;
    private StringBuffer address; 
    StringBuffer sb=new StringBuffer();
    public StringBuffer getSb() {
		return sb;
	}

	public void setSb(StringBuffer sb) {
		this.sb = sb;
	}
	
    public enum Gender{
    	 M,f;
    }
   public StringBuffer getAddress() {
		return address;
	}

	public void setAddress(StringBuffer address) {
		this.address = address;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	/* private double balance;*/
	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

/*	public double getBalance() {
		return balance;*/
	

	public Customer() {
		super();
	}

	public Customer(long accNo, int pin, String fName, String lName, String e_mail, int age, String gender,
			long aadharNo, long mobileNO) {
		super();
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getE_mail() {
		return e_mail;
	}

	public void setE_mail(String e_mail) {
		this.e_mail = e_mail;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getMobileNO() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		return " Your Deatils:\nFirst Name :"+fName+"\nLast Name  :"+lName+"\nAddress    :"+address+"\nAge        :"+age+"\nAadhar Number:"+aadharNo+"\nMobile NUmber:"+mobileNo+"\nGender     :"+gender+"\nE_mail     :"+e_mail+"\nAccount Balance:" +amount;

	}
	public void setBalance(double amt) {
		// TODO Auto-generated method stub
		
	}
}