package com.capg.ba.dao;

import java.util.HashMap;
import java.util.Map;
import com.capg.ba.bean.Customer;

public class CustomerDaoImp implements ICustomerdao {
	Map<Long, Customer> custList = new HashMap<Long, Customer>();
	Map<Long, StringBuffer> transaction = new HashMap<Long, StringBuffer>();

	@Override
	public boolean createAccount(Customer cus) {
		// TODO Auto-generated method stub
		long key = cus.getAccNo();
		custList.put(key, cus);
		return custList.containsValue(cus);
	}

	@Override
	public double showBalance(long cid, int pin) {
		// TODO Auto-generated method stub
		double a = 0;
		for (Customer c : custList.values()) {
			if ((c.getAccNo() == cid) && (c.getPin() == pin)) {
				a = c.getAmount();
				System.out.println("Balance is:" + a);

			}
		}
		return a;
	}

	@Override
	public double deposit(Customer c, double amount) {
		
		return c.getAmount();
	}

	@Override
	public double withDraw(Customer c, double amount) {
		
		return c.getAmount();
	}

	@Override
	public boolean fundTransfer(Customer c, Customer b, double amount, long acc1, long acc2, int pin1) {
		// TODO Auto-generated method stub
		boolean flag = false;
		if (c.getAccNo() == acc1 && c.getPin() == pin1) {
			if (b.getAccNo() == acc2) {
				if (c.getAmount() > amount) {
					flag = true;
				}
			}
		}
		return flag;
	}

	@Override
	public Customer printTransactions(long cid, int pin) {
		// TODO Auto-generated method stub
		if (transaction.containsKey(cid)) {
			Object trns = transaction.get(cid);
			System.out.println("Account number : " + cid + "\n" + trns + "\n");
		}
		return null;
	}

	@Override
	public Customer printTransaction(Customer cid) {
		Customer cust = null;
		long acc = cid.getAccNo();
		StringBuffer sb = new StringBuffer();
		sb = cid.getSb();
		sb.append(cid.getAmount());
		cid.setSb(sb);
		transaction.put(acc, sb);
		for (StringBuffer transaction1 : transaction.values()) {
			transaction.entrySet().stream().forEach(System.out::println);
			System.out.println("Transaction");
		}
		return cust;

	}

	public boolean validateAccountNumber(long cid) {
		// TODO Auto-generated method stub
		boolean flag = false;
		for (Customer c : custList.values()) {
			if (c.getAccNo() == cid) {
				flag = true;
				;
			}

		}
		return flag;
	}

	public boolean validatePin(int pin) {
		// TODO Auto-generated method stub
		boolean flag = false;
		for (Customer c : custList.values()) {
			if (c.getPin() == pin) {
				flag = true;
			}
		}
		return flag;
	}

	@Override
	public Customer displayCustomer(long accNo) {
		// TODO Auto-generated method stub
		Customer custo = null;
		for (Customer c : custList.values()) {
			if ((c.getAccNo() == accNo)) {
				custo = c;
			}
		}
		return custo;
	}

	

}
