package com.capg.ba.dao;

import com.capg.ba.bean.Customer;

public interface ICustomerdao {

	Customer printTransactions(long cid, int pin);

	Customer printTransaction(Customer cid);

	Customer displayCustomer(long accNo);

	boolean fundTransfer(Customer c, Customer b, double amount, long acc1, long acc2, int pin1);

	double withDraw(Customer c, double amount);

	double deposit(Customer c, double amount);

	boolean createAccount(Customer cus);

	double showBalance(long cid, int pin);

	

}
